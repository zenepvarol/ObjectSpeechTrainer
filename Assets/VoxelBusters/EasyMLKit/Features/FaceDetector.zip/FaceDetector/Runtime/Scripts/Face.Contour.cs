using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EasyMLKit
{
    public partial class Face
    {
        public enum ContourType
        {
            Face = 1,
            LeftEyeBrowTop,
            LeftEyeBrowBottom,
            RightEyeBrowTop,
            RightEyeBrowBottom,
            LeftEye,
            RightEye,
            UpperLipTop,
            UpperLipBottom,
            LowerLipTop,
            LowerLipBottom,
            NoseBridge,
            NoseBottom,
            LeftCheek,
            RightCheek
        }

        public class Contour
        {
            public ContourType FaceContourType
            {
                get;
                private set;
            }

            public Vector2[] Points
            {
                get;
                private set;
            }


            public Contour(ContourType type, Vector2[] points)
            {
                FaceContourType = type;
                Points = points;
            }
        }

    }
}
