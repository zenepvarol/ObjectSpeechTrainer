using UnityEngine;

namespace VoxelBusters.EasyMLKit
{
    public partial class Face
    {
        public enum LandmarkType
        {
            MouthBottom = 0,
            LeftCheek = 1,
            LeftEar = 3,
            LeftEye = 4,
            MouthLeft = 5,
            NoseBase = 6,
            RightCheek = 7,
            RightEar = 9,
            RightEye = 10,
            MouthRight = 11
        }

        public class Landmark
        {
            public LandmarkType FaceLandmarkType
            {
                get;
                private set;
            }

            public Vector2 Position
            {
                get;
                private set;
            }


            public Landmark(LandmarkType type, Vector2 position)
            {
                FaceLandmarkType = type;
                Position = position;
            }
        }

    }
}
