﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EasyMLKit
{
    public partial class Face
    {
        public Rect BoundingBox
        {
            get;
            private set;
        }

        public List<Face.Contour> Contours
        {
            get;
            private set;
        }

        public List<Face.Landmark> Landmarks
        {
            get;
            private set;
        }

        public Vector3 HeadRotation
        {
            get;
            private set;
        }

        public float? LeftEyeOpenProbability
        {
            get;
            private set;
        }

        public float? RightEyeOpenProbability
        {
            get;
            private set;
        }

        public float? SmilingProbability
        {
            get;
            private set;
        }

        public int? TrackingId
        {
            get;
            private set;
        }

        public Face()
        {
        }

        public override string ToString()
        {
            return $"Bounding Box : {BoundingBox} TrackingId : {TrackingId} HeadRotation : {HeadRotation}";
        }
    }
}