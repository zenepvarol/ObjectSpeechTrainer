﻿using VoxelBusters.CoreLibrary;
using VoxelBusters.EasyMLKit.Internal;

namespace VoxelBusters.EasyMLKit.Implementations.Null
{
    public class FaceDetectorImplementation : IFaceDetectorImplementation
    {
        private string NotAvailable = "Not available on this platform";
        public FaceDetectorImplementation(IInputSource inputSource)
        {
        }

        public void Prepare(FaceDetectorOptions options, OnPrepareCompleteInternalCallback callback)
        {
            if (callback != null)
            {
                callback(new Error(NotAvailable));
            }
        }

        public void Process(OnProcessUpdateInternalCallback<FaceDetectorResult> callback)
        {
            if (callback != null)
            {
                callback(new FaceDetectorResult(null, new Error(NotAvailable)));
            }
        }

        public void Close(OnCloseInternalCallback callback)
        {
            if (callback != null)
            {
                callback(new Error(NotAvailable));
            }
        }
    }
}