﻿#if UNITY_EDITOR
using System.Collections.Generic;
using VoxelBusters.EasyMLKit.Internal;

namespace VoxelBusters.EasyMLKit.Implementations.Simulator
{
    public class FaceDetectorImplementation : IFaceDetectorImplementation
    {
        public FaceDetectorImplementation(IInputSource source)
        {
        }

        public void Prepare(FaceDetectorOptions options, OnPrepareCompleteInternalCallback callback)
        {
            if (callback != null)
            {
                callback(null);
            }
        }

        public void Process(OnProcessUpdateInternalCallback<FaceDetectorResult> callback)
        {
            if (callback != null)
            {
                callback(new FaceDetectorResult(CreateDummyFaces(), null));
            }
        }

        public void Close(OnCloseInternalCallback callback)
        {
            if (callback != null)
            {
                callback(null);
            }
        }

        private List<Face> CreateDummyFaces()
        {
            List<Face> faces = new List<Face>();
            Face.Builder builder = new Face.Builder();
            builder.SetBoundingBox(UnityEngine.Rect.zero);
            faces.Add(builder.Build());
            return faces;
        }
    }
}
#endif